﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLib;
using DataAccessLib;
using ExceptionLib;


namespace BusinessLib
{
    public class BusinessLayer  : IBusiness
    {
        //for adding contact
        public void AddContact(Contact contact)
        {
            try
            {
                DataAccess dal = new DataAccess();
                dal.AddContact(contact);

            }
            catch (PbException ex)
            {
                throw ex;

            }


        }
        //for adding category
        public void AddCategory(Category category)
        {
            try
            {
                DataAccess dal = new DataAccess();
                dal.AddCategory(category);
            }
            catch(PbException ex)
            {
                throw ex;

                
            }

        }
        //for deleting contact
        public void DeleteContactById(int id)
        {
            try
            {
                DataAccess dal = new DataAccess();
                dal.DeleteContactById(id);
            }
            catch (PbException ex)
            {
                throw ex;
            }
        }
        //for deleting categoryById
        public void DeleteCategoryById(int id)
        {
            try
            {
                DataAccess dal = new DataAccess();
                dal.DeleteContactById(id);
            }
            catch (PbException ex)
            {
                throw ex;
            }

        }
        //for getting all category names
        public List<Category> GetAllCategoryNames()
        {
            try
            {
                DataAccess dal = new DataAccess();
                var lstcategories = dal.GetAllCategoryNames();
                return lstcategories;
            }
            catch(PbException ex)
            {
                throw ex;
            }
        }
        //for getting all contacts


        public List<Contact> GetAllContactsByCId(int id)
        {
            try
            {
                DataAccess dal = new DataAccess();
                var lstcontacts = dal.GetAllContactsByCId(id);
                return lstcontacts;

            }
            catch (PbException ex)
            {
                throw ex;

            }
        }
        //for updaating contact
        public void UpdateContactById(Contact contact)
        {
            try
            {
                DataAccess dal = new DataAccess();
                dal.UpdateContactById(contact);
            }
            catch (PbException ex)
            {
                throw ex;

            }
        }
        //for updating category
        public void UpdateCategoryById(Category category)
        {
            try
            {
                DataAccess dal = new DataAccess();
                dal.UpdateCategoryById(category);

            }
            catch (PbException ex)
            {
                throw ex;
            }
        }

    }

    public interface IBusiness
    {
    }
}     


            

        
          
           






    


 


