﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLib;
using ExceptionLib;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace DataAccessLib
{
    public class DataAccess : IDataAccess
    {
        SqlCommand cmd;
        SqlConnection con;
        public DataAccess()
        {
            con = new SqlConnection();
           
            con.ConnectionString = "@Data Source=(localdb) MSSQLLocalDB;Initial Catalog=HCLDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False ";

        }
        public List<Category> GetAllCategoryNames()
        {
            List<Category> lstcategory = new List<Category>();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "select * from Category";
                cmd.Connection = con;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Category category = new Category
                    {
                       
                       
                            CategoryId= (int)sdr[0],
                            CategoryName = sdr[1].ToString(),
                    };
                        
                 lstcategory.Add(category);


                }
                sdr.Close();

            }
            catch (SqlException ex)
            {
                throw new PbException(ex.Message);

            }
            catch (Exception ex)
            {
                throw new PbException(ex.Message);

            }
            finally
            {
                con.Close();

            }
            return lstcategory;

        }
        public void AddCategory(Category category)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "insert into Category values(@catid,@catname)";
                cmd.Connection = con;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@catid", category.CategoryId);
                cmd.Parameters.AddWithValue("@catname", category.CategoryName);
                cmd.CommandType = CommandType.Text;
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new PbException("Could not insert data");

                }
            }
            catch (SqlException ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            catch (Exception ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            finally
            {
                con.Close();

            }
        }
        public void AddContact(Contact contact)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "insert into Contact values(@conid,@catid,@fname,@lname,@gender,@cnumber,@city,@state,@con,@pic)";
                cmd.Connection = con;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@conid", contact.ContactId);
                cmd.Parameters.AddWithValue("@catid", contact.CategoryId);
                cmd.Parameters.AddWithValue("@fname", contact.FirstName);
                cmd.Parameters.AddWithValue("@lname", contact.LastName);
                cmd.Parameters.AddWithValue("@gender", contact.Gender);
                cmd.Parameters.AddWithValue("@cnum", contact.ContactNumber);
                cmd.Parameters.AddWithValue("@mailid", contact.EmailId);
                cmd.Parameters.AddWithValue("@city", contact.City);
                cmd.Parameters.AddWithValue("@state", contact.State);
                cmd.Parameters.AddWithValue("@con", contact.Country);
                cmd.Parameters.AddWithValue("@pic", contact.Pic);
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new PbException("Could not insert record!!!");

                }
            }
            catch (SqlException )
            {
                throw new PbException("some error has happened!: + ex.Message");
            }
            catch (Exception )
            {
                throw new PbException("some error has happened!: + ex.Message");

            }
            finally
            {
                con.Close();
            }
        }
        public void DeleteContactById(int id)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "delete from Contact where ContactId=@id";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Connection = con;
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new PbException("ContactId does not exists");
                }

            }

            catch (SqlException ex)
            {
                throw new PbException("some error has happened" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new PbException("some error has happened" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        public void DeleteCategoryById(int id)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "delete from Category where CategoryId=@id";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Connection = con;
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new PbException("CategoryId does not Exists");

                }
            }
            catch (SqlException ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            catch (Exception ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            finally
            {
                con.Close();

            }
        }
        public List<Contact> GetAllContactsByCId(int id)
        {
            List<Contact> lstcon = new List<Contact>();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "select Contact.ContactId,Category.CategoryId,Contact.FirstName,Contact.LastName,Contact.Gender,Contact.ContactNumber,Contact.EmailId,Contact.State,Contact.Country,Contact.Picture from Category join Contact ON Category.CategoryId=Contact.ContactId and Contact.CategoryId=@ci";
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ci", id);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Contact contact = new Contact
                    {
                        ContactId = (int)sdr[0],
                        CategoryId = (int)sdr[1],
                        FirstName = sdr[2].ToString(),
                        LastName = sdr[3].ToString(),
                        Gender = sdr[4].ToString(),
                        ContactNumber = Convert.ToInt64(sdr[5]),
                        EmailId = sdr[6].ToString(),
                        City = sdr[7].ToString(),
                        State = sdr[8].ToString(),
                        Country = sdr[9].ToString(),
                        Pic = sdr[10].ToString()
                    };
                    lstcon.Add(contact);

                }
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new PbException("some error has happened" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new PbException("some error has happened" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return lstcon;
        }
        public void UpdateContactById(Contact contact)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "update Contact set ContactId=@ci,CategoryId=@catid,FirstName=@fname,LastName=@lname,Gender=@gen,ContactNumber=@pn,EmailId=@eid,City=@c,State=@st,Country=@co,Picture=@pic where ContactId=@ci";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@ci", contact.ContactId);
                cmd.Parameters.AddWithValue("@catid", contact.CategoryId);
                cmd.Parameters.AddWithValue("@fname", contact.FirstName);
                cmd.Parameters.AddWithValue("@lname", contact.LastName);
                cmd.Parameters.AddWithValue("@gen", contact.Gender);
                cmd.Parameters.AddWithValue("@pn", contact.ContactNumber);
                cmd.Parameters.AddWithValue("@eid", contact.EmailId);
                cmd.Parameters.AddWithValue("@c", contact.City);
                cmd.Parameters.AddWithValue("@st", contact.State);
                cmd.Parameters.AddWithValue("@co", contact.Country);
                cmd.Parameters.AddWithValue("@pic", contact.Pic);
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new PbException("ContactId doesnot Exists");

                }
            }
            catch (SqlException ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            catch (Exception ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            finally
            {
                con.Close();

            }
        }
        public void UpdateCategoryById(Category category)
        {
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "update Category set CategoryId=@catid,CategoryName=@catname where CategoryId=@ci";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@catid", category.CategoryId);
                cmd.Parameters.AddWithValue("@ci", category.CategoryName);
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                if (recordsAffected == 0)
                {
                    throw new PbException("Could not update category");

                }
            }
            catch (SqlException ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
            catch (Exception ex)
            {
                throw new PbException("some error has happened" + ex.Message);

            }
           


        }


        
    }


}

            




       

  

        
            
       
        

       
       
        

        
 

