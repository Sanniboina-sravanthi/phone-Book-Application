﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using EntitiesLib;
using Newtonsoft.Json;

namespace PhoneBookApp.Controllers
{
    public class PhoneBookAppController : Controller
    {
        // GET: PhoneBookApp
        public ActionResult HomePage()
        {
            return View();
        }
        public ActionResult Categories()
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("PhoneBookApi").Result;
                var lstCategory = JsonConvert.DeserializeObject<List<Category>>(result);
                return View(lstCategory);

            }


        }
        public ActionResult ContactDetails(int id)
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("PhoneBookApi/" + id).Result;
                var lstContacts = JsonConvert.DeserializeObject<List<Contact>>(result);
                return View(lstContacts);


            }
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();

        }
        [HttpPost]
        public ActionResult Create(Category category)
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using(var client = new HttpClient())

            {
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync("PhoneBookApi", category).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    return RedirectToAction("Categories");

                }
                else
                {
                    ViewData.Add("msg", "record is not inserted");

                }
                return View();

            }
        }
        [HttpGet]
        public ActionResult CreateContact()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateContact(Contact contact)
        {
            Uri uri = new Uri("http://localhost:61373/api");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync("PhoneBookApi/AddContact", contact).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    return RedirectToAction("ContactDetails", new { id = contact.CategoryId });

                }
                else
                {
                    ViewData.Add("msg", "record is not inserted");
                }
                return View();

            }
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.DeleteAsync("PhoneBookApi/" + id).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    TempData.Add("msg", "record deleted successfully");
                }
                else
                {
                    TempData.Add("msg", "record could not delete due some error");

                }
                return RedirectToAction("Categories");

            }
        }
        [HttpGet]
        public ActionResult DeleteContact(int id)
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.DeleteAsync("PhoneBookApi/DeleteContact" + id).Result;
                return RedirectToAction("ContactDetails");

            }
        }
        
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("PhoneBookApi/" + id).Result;
                var category = JsonConvert.DeserializeObject<Category>(result);
                return View(category);

            }                  
        }
        [HttpPost]
        public ActionResult Edit(Contact contact)
        {
            Uri uri = new Uri("http://localhost:61373/api/");
            using(var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PutAsJsonAsync("PhoneBookApi/" + contact.ContactId, contact).Result;
                return RedirectToAction("ContactDetails");
            }
        }
    }

}

            
        
        
    
